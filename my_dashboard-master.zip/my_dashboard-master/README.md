DASHBOARD with:
- React 18
- React-router-dom v6
- Redux, Redux toolkit
- styled-components
- typescript
- axios, jest, moment
...and more

UI components, Chat, Profile page, Auth and more
Node.js, express, mongoDB

work in progress
