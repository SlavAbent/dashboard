import React from 'react';

const Main = () => {
    return (
        <>1</>
    )
}

export default Main