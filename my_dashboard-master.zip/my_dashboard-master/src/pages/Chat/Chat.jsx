import React from 'react';

const Chat = () => {
    return (
        <>2</>
    )
}

export default Chat