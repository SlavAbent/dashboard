import React from 'react';

const Profile = () => {
    return (
        <>3</>
    )
}

export default Profile