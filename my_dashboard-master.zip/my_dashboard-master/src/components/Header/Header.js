import React from 'react';
import { HeaderComponent } from './Header.style'

const Header = () => {
    return (
        <HeaderComponent>
                1342
        </HeaderComponent>
    )
}

export default Header