import styled from 'styled-components';

const RoutesComponent = styled.div`
    margin-top: 40px;
    position: absolute;
    top: 50px;
    left: 100px;
`;

export { RoutesComponent }