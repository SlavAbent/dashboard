import React from 'react';
import { Routes, Route } from 'react-router-dom'
import { RoutesComponent } from './RoutesWrapper.style'

import Main from '../pages/Main/Main'
import UI from '../pages/UI/UI'
import Chat from '../pages/Chat/Chat'
import Profile from '../pages/Profile/Profile'


export const RoutesWrapper = () => {
    return (
        <RoutesComponent>
            <Routes>
                <Route exact  path="/" index element={<Main />} />
                <Route exact  path="UI" element={<UI />} />
                <Route exact  path="Chat" element={<Chat />} />
                <Route exact  path="Profile" element={<Profile />} />
            </Routes>
        </RoutesComponent>
    )
}