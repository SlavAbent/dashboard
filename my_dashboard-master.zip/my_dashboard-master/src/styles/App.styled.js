import styled from 'styled-components'


const AppWrapper = styled.div`
    display: flex;
    width: 100%;
    height: 100vh
`;

export { AppWrapper }
